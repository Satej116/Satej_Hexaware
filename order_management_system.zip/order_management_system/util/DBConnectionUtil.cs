﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order_management_system.util
{
    public class DBConnUtil
    {
        public static SqlConnection GetConnection()
        {
            string connectionString = DBPropertyUtil.GetConnectionString();
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }
    }
}
