﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace order_management_system.util
{
    public class DBPropertyUtil
    {
        public static string GetConnectionString()
        {
            return "Server=LAPTOP-9GQFB99R;Database=order_management_db;Trusted_Connection=True;";
        }
    }
}
