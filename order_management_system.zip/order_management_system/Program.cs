﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using order_management_system.dao;
using order_management_system.entites;
using order_management_system.exception;
using order_management_system.util;

namespace order_management_system
{
    class MainModule
    {
        static void Main(string[] args)
        {
            OrderProcessor processor = new OrderProcessor();
            bool running = true;

            while (running)
            {
                Console.WriteLine("\n=========== Order Management System ===========");
                Console.WriteLine("1. Create User/Admin");
                Console.WriteLine("2. Create Product (Admin Only)");
                Console.WriteLine("3. Place Order");
                Console.WriteLine("4. Cancel Order");
                Console.WriteLine("5. View All Products");
                Console.WriteLine("6. View Orders by User");
                Console.WriteLine("7. Exit");
                Console.Write("Enter your choice: ");

                if (!int.TryParse(Console.ReadLine(), out int choice))
                {
                    Console.WriteLine("Invalid input. Please enter a number.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        // Create User/Admin
                        string uname = ReadNonEmptyInput("Enter Username: ");
                        string pass = ReadNonEmptyInput("Enter Password: ");
                        string role = ReadNonEmptyInput("Enter Role (admin/user): ");

                        User newUser = new User
                        {
                            Username = uname,
                            Password = pass,
                            Role = role
                        };

                        processor.CreateUser(newUser);
                        Console.WriteLine("User created successfully. Assigned User ID: " + newUser.UserId);
                        break;

                    case 2:
                        // Create Product (Admin)
                        try
                        {
                            Console.Write("Enter Admin User ID: ");
                            int adminId = Convert.ToInt32(Console.ReadLine());

                            SqlConnection conn = DBConnUtil.GetConnection();
                            conn.Open();
                            string checkQuery = "select role from users where user_id = " + adminId;
                            SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                            object roleObj = checkCmd.ExecuteScalar();
                            conn.Close();

                            if (roleObj == null)
                                throw new UserNotFoundException("User ID " + adminId + " not found.");

                            string actualRole = roleObj.ToString().ToLower();
                            if (actualRole != "admin")
                            {
                                Console.WriteLine("Access denied. Only admins can create products.");
                                break;
                            }

                            User adminUser = new User { UserId = adminId, Role = "admin" };

                            int pid = int.Parse(ReadNonEmptyInput("Enter Product ID: "));
                            string pname = ReadNonEmptyInput("Enter Product Name: ");
                            string desc = ReadNonEmptyInput("Enter Description: ");
                            double price = double.Parse(ReadNonEmptyInput("Enter Price: "));
                            int qty = int.Parse(ReadNonEmptyInput("Enter Quantity: "));
                            string type = ReadNonEmptyInput("Enter Type (electronics/clothing): ").ToLower();

                            if (type == "electronics")
                            {
                                string brand = ReadNonEmptyInput("Enter Brand: ");
                                int warranty = int.Parse(ReadNonEmptyInput("Enter Warranty Period (months): "));
                                Electronics e = new Electronics(pid, pname, desc, price, qty, brand, warranty);
                                processor.CreateProduct(adminUser, e);
                            }
                            else if (type == "clothing")
                            {
                                string size = ReadNonEmptyInput("Enter Size: ");
                                string color = ReadNonEmptyInput("Enter Color: ");
                                Clothing c = new Clothing(pid, pname, desc, price, qty, size, color);
                                processor.CreateProduct(adminUser, c);
                            }
                            else
                            {
                                Console.WriteLine("Invalid type. Use 'electronics' or 'clothing'.");
                            }
                        }
                        catch (UserNotFoundException ex)
                        {
                            Console.WriteLine("Error: " + ex.Message);
                        }
                        break;

                    case 3:
                        // Place Order
                        try
                        {
                            int orderUserId = int.Parse(ReadNonEmptyInput("Enter User ID: "));

                            SqlConnection conn = DBConnUtil.GetConnection();
                            conn.Open();
                            string checkQuery = "select count(*) from users where user_id = " + orderUserId;
                            SqlCommand checkCmd = new SqlCommand(checkQuery, conn);
                            int count = Convert.ToInt32(checkCmd.ExecuteScalar());
                            conn.Close();

                            if (count == 0)
                                throw new UserNotFoundException("User with ID " + orderUserId + " does not exist.");

                            User orderUser = new User { UserId = orderUserId };

                            Console.WriteLine("\n--- Available Products ---");
                            List<Product> availableProducts = processor.GetAllProducts();
                            foreach (var p in availableProducts)
                            {
                                Console.WriteLine($"{p.ProductId} | {p.ProductName} | {p.Description} | Rs.{p.Price} | Qty: {p.QuantityInStock} | Type: {p.Type}");
                            }

                            int n = int.Parse(ReadNonEmptyInput("How many products to order? "));
                            List<Product> productList = new List<Product>();

                            for (int i = 0; i < n; i++)
                            {
                                int pId = int.Parse(ReadNonEmptyInput("Enter Product ID " + (i + 1) + ": "));
                                productList.Add(new Product { ProductId = pId });
                            }

                            processor.CreateOrder(orderUser, productList);
                        }
                        catch (UserNotFoundException ex)
                        {
                            Console.WriteLine("Error: " + ex.Message);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Error: " + ex.Message);
                        }
                        break;

                    case 4:
                        // Cancel Order
                        int cancelUid = int.Parse(ReadNonEmptyInput("Enter User ID: "));
                        int cancelOid = int.Parse(ReadNonEmptyInput("Enter Order ID: "));
                        processor.CancelOrder(cancelUid, cancelOid);
                        break;

                    case 5:
                        // View All Products
                        List<Product> allProducts = processor.GetAllProducts();
                        Console.WriteLine("\n--- All Products ---");
                        foreach (var p in allProducts)
                        {
                            Console.WriteLine($"{p.ProductId} | {p.ProductName} | {p.Description} | Rs.{p.Price} | Qty: {p.QuantityInStock} | Type: {p.Type}");
                        }
                        break;

                    case 6:
                        // View Orders by User
                        int viewUid = int.Parse(ReadNonEmptyInput("Enter User ID: "));
                        User viewUser = new User { UserId = viewUid };
                        List<Product> userOrders = processor.GetOrderByUser(viewUser);

                        Console.WriteLine("\n--- Products Ordered by User ---");
                        foreach (var p in userOrders)
                        {
                            Console.WriteLine($"{p.ProductId} | {p.ProductName} | {p.Description} | Rs.{p.Price} | Type: {p.Type}");
                        }
                        break;

                    case 7:
                        running = false;
                        Console.WriteLine("Exited successfully.");
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Please enter a number from 1 to 7.");
                        break;
                }
            }
        }

        //Its helper method
        static string ReadNonEmptyInput(string prompt)
        {
            string input;
            do
            {
                Console.Write(prompt);
                input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Input cannot be empty. Please try again.");
                }
            } while (string.IsNullOrWhiteSpace(input));
            return input;
        }
    }

}
