﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using order_management_system.entites;
using order_management_system.exception;
using order_management_system.util;

namespace order_management_system.dao
{
    public class OrderProcessor : IOrderManagementRepository
    {
        SqlConnection connection;

        public OrderProcessor()
        {
            connection = DBConnUtil.GetConnection();
        }

        public void CreateUser(User user)
        {
            try
            {
                connection.Open();
                string query = "insert into users (username, password, role) values ('" + user.Username + "', '" + user.Password + "', '" + user.Role + "'); select scope_identity();";
                SqlCommand cmd = new SqlCommand(query, connection);
                int newUserId = Convert.ToInt32(cmd.ExecuteScalar());
                Console.WriteLine("User created successfully. New user ID = " + newUserId);
                user.UserId = newUserId;

            }
            catch (Exception ex)
            {
                Console.WriteLine("Error creating user: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        public void CreateProduct(User user, Product product)
        {
            if (user.Role.ToLower() != "admin")
            {
                Console.WriteLine("Only admins can add products.");
                return;
            }

            try
            {
                connection.Open();
                string query = "insert into products values (" + product.ProductId + ", '" + product.ProductName + "', '" + product.Description + "', " + product.Price + ", " + product.QuantityInStock + ", '" + product.Type + "')";
                SqlCommand cmd = new SqlCommand(query, connection);
                cmd.ExecuteNonQuery();

                if (product.Type.ToLower() == "electronics")
                {
                    Electronics e = (Electronics)product;
                    string eQuery = "insert into electronics_products values (" + e.ProductId + ", '" + e.Brand + "', " + e.WarrantyPeriod + ")";
                    SqlCommand ecmd = new SqlCommand(eQuery, connection);
                    ecmd.ExecuteNonQuery();
                }
                else if (product.Type.ToLower() == "clothing")
                {
                    Clothing c = (Clothing)product;
                    string cQuery = "insert into clothing_products values (" + c.ProductId + ", '" + c.Size + "', '" + c.Color + "')";
                    SqlCommand ccmd = new SqlCommand(cQuery, connection);
                    ccmd.ExecuteNonQuery();
                }

                Console.WriteLine("Product added.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error creating product: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        public void CreateOrder(User user, List<Product> products)
        {
            try
            {
                connection.Open();

                string orderQuery = "insert into orders (user_id, order_date) values (" + user.UserId + ", '" + DateTime.Now.ToString("yyyy-MM-dd") + "')";
                SqlCommand orderCmd = new SqlCommand(orderQuery, connection);
                orderCmd.ExecuteNonQuery();

                SqlCommand getIdCmd = new SqlCommand("select max(order_id) from orders", connection);
                int orderId = Convert.ToInt32(getIdCmd.ExecuteScalar());

                foreach (Product p in products)
                {
                    string itemQuery = "insert into order_items values (" + orderId + ", " + p.ProductId + ")";
                    SqlCommand itemCmd = new SqlCommand(itemQuery, connection);
                    itemCmd.ExecuteNonQuery();
                }

                Console.WriteLine($"Order placed successfully.Your Order_ID is {orderId}");
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error placing order: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        public void CancelOrder(int userId, int orderId)
        {
            try
            {
                connection.Open();
                string checkQuery = "select * from orders where order_id = " + orderId + " and user_id = " + userId;
                SqlCommand checkCmd = new SqlCommand(checkQuery, connection);
                SqlDataReader reader = checkCmd.ExecuteReader();

                if (!reader.HasRows)
                {
                    reader.Close();
                    throw new OrderNotFoundException("Order not found for this user.");
                }
                reader.Close();

                string deleteItems = "delete from order_items where order_id = " + orderId;
                SqlCommand delItemsCmd = new SqlCommand(deleteItems, connection);
                delItemsCmd.ExecuteNonQuery();

                string deleteOrder = "delete from orders where order_id = " + orderId;
                SqlCommand delOrderCmd = new SqlCommand(deleteOrder, connection);
                delOrderCmd.ExecuteNonQuery();

                Console.WriteLine("Order cancelled.");
            }
            catch (OrderNotFoundException ex)
            {
                Console.WriteLine("Custom Exception: " + ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error cancelling order: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        public List<Product> GetAllProducts()
        {
            List<Product> products = new List<Product>();

            try
            {
                connection.Open();
                string query = "select * from products";
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();

                // Step 1: Read raw data into a temporary list
                List<(int, string, string, double, int, string)> rawList = new List<(int, string, string, double, int, string)>();

                while (reader.Read())
                {
                    rawList.Add((
                        Convert.ToInt32(reader["product_id"]),
                        reader["product_name"].ToString(),
                        reader["description"].ToString(),
                        Convert.ToDouble(reader["price"]),
                        Convert.ToInt32(reader["quantity_in_stock"]),
                        reader["type"].ToString().ToLower()
                    ));
                }

                reader.Close(); 

                
                foreach (var item in rawList)
                {
                    int id = item.Item1;
                    string name = item.Item2;
                    string desc = item.Item3;
                    double price = item.Item4;
                    int qty = item.Item5;
                    string type = item.Item6;

                    if (type == "electronics")
                    {
                        string brand = GetBrand(id);
                        int warranty = GetWarranty(id);
                        products.Add(new Electronics(id, name, desc, price, qty, brand, warranty));
                    }
                    else if (type == "clothing")
                    {
                        string size = GetSize(id);
                        string color = GetColor(id);
                        products.Add(new Clothing(id, name, desc, price, qty, size, color));
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error fetching products: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return products;
        }

        public List<Product> GetOrderByUser(User user)
        {
            List<Product> ordered = new List<Product>();

            try
            {
                connection.Open();
                string query = "select p.* from orders o join order_items oi on o.order_id = oi.order_id join products p on oi.product_id = p.product_id where o.user_id = " + user.UserId;
                SqlCommand cmd = new SqlCommand(query, connection);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    Product p = new Product();
                    p.ProductId = Convert.ToInt32(reader["product_id"]);
                    p.ProductName = reader["product_name"].ToString();
                    p.Description = reader["description"].ToString();
                    p.Price = Convert.ToDouble(reader["price"]);
                    p.QuantityInStock = Convert.ToInt32(reader["quantity_in_stock"]);
                    p.Type = reader["type"].ToString();
                    ordered.Add(p);
                }
                reader.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error fetching order: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return ordered;
        }

        // Basic helper methods
        private string GetBrand(int productId)
        {
            string brand = "";
            string query = "select brand from electronics_products where product_id = " + productId;
            SqlCommand cmd = new SqlCommand(query, connection);
            object result = cmd.ExecuteScalar();
            if (result != null)
                brand = result.ToString();
            return brand;
        }

        private int GetWarranty(int productId)
        {
            int warranty = 0;
            string query = "select warranty_period from electronics_products where product_id = " + productId;
            SqlCommand cmd = new SqlCommand(query, connection);
            object result = cmd.ExecuteScalar();
            if (result != null)
                warranty = Convert.ToInt32(result);
            return warranty;
        }

        private string GetSize(int productId)
        {
            string size = "";
            string query = "select size from clothing_products where product_id = " + productId;
            SqlCommand cmd = new SqlCommand(query, connection);
            object result = cmd.ExecuteScalar();
            if (result != null)
                size = result.ToString();
            return size;
        }

        private string GetColor(int productId)
        {
            string color = "";
            string query = "select color from clothing_products where product_id = " + productId;
            SqlCommand cmd = new SqlCommand(query, connection);
            object result = cmd.ExecuteScalar();
            if (result != null)
                color = result.ToString();
            return color;
        }
    }
}
