order_management_system/
├── entites/                  # Entity classes: User, Product, Electronics, Clothing
├── dao/                      # Data Access: OrderProcessor implementing IOrderManagementRepository
├── exception/                # Custom exceptions like UserNotFoundException
├── util/                     # DB connection utility class
├── MainModule.cs             #(menu-driven interface)
├── database_schema.txt       # Contains SQL table creation & insert queries
└── README.md                 # Project documentation (this file)

Connection string is correct in Util/DBPropertyUtil.cs.