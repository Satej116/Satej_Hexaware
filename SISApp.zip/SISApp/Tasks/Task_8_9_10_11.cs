﻿//using System;
//using System.Collections.Generic;
//using System.Data.SqlClient;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace SISApp
//{
//    public class Task_8_9_10_11
//    {
//        static DBHandler db = new DBHandler();

//        // Task 8: Enroll John Doe in 2 courses
//        public static void EnrollJohnDoe()
//        {
//            SqlConnection con = db.GetConnection();
//            con.Open();

//            string enableIdentityInsert = "SET IDENTITY_INSERT Students ON;";

//            SqlCommand enableCmd = new SqlCommand(enableIdentityInsert, con);


//            string insStudent = "INSERT INTO Students (student_id,first_name, last_name, date_of_birth, email, phone_number) " +
//                                 "VALUES (301, 'Johns', 'Don', '2000-08-15', 'johns.don@example.com', '1234564567')";
//            SqlCommand cmd1 = new SqlCommand(insStudent, con);

//            string disableIdentityInsert = "SET IDENTITY_INSERT Students OFF;";
//            SqlCommand disableCmd = new SqlCommand(disableIdentityInsert, con);

//            enableCmd.ExecuteNonQuery();
//            cmd1.ExecuteNonQuery();
//            disableCmd.ExecuteNonQuery();

//            Console.WriteLine("1 row(s) inserted into Students");

//            string insEnroll1 = "INSERT INTO Enrollments (student_id, course_id) VALUES (301, 8)";
//            SqlCommand cmd2 = new SqlCommand(insEnroll1, con);
//            int rows2 = cmd2.ExecuteNonQuery();
//            Console.WriteLine(rows2 + " row(s) inserted into Enrollments");

//            string insEnroll2 = "INSERT INTO Enrollments (student_id, course_id) VALUES (301, 10)";
//            SqlCommand cmd3 = new SqlCommand(insEnroll2, con);
//            int rows3 = cmd3.ExecuteNonQuery();
//            Console.WriteLine(rows3 + " row(s) inserted into Enrollments");

//            con.Close();
//        }

//        // Task 9: Assign Sarah Smith to 6 (Note:- Course_id =CS302 did'nt exsits in database so I used 6)
//        public static void AssignTeacherToCourse()
//        {
//            SqlConnection con = db.GetConnection();
//            con.Open();

//            string enableIdentityInsert = "SET IDENTITY_INSERT Teacher ON;";
            
//            SqlCommand enableCmd = new SqlCommand(enableIdentityInsert, con);
            

//            string insTeacher = "INSERT INTO Teacher (teacher_id, first_name, last_name, email) " +
//                                 "VALUES (301, 'Sarah', 'Smith', 'sarah.smith@example.com')";
//            SqlCommand cmd4 = new SqlCommand(insTeacher, con);

//            string disableIdentityInsert = "SET IDENTITY_INSERT Teacher OFF;";
//            SqlCommand disableCmd = new SqlCommand(disableIdentityInsert, con);
            
//            enableCmd.ExecuteNonQuery();
//            cmd4.ExecuteNonQuery();
//            disableCmd.ExecuteNonQuery();

//            Console.WriteLine("1 row(s) inserted into Teacher");

//            string updCourse = "UPDATE Courses SET teacher_id = 301 WHERE course_code = '6'";
//            SqlCommand cmd5 = new SqlCommand(updCourse, con);
//            int rows5 = cmd5.ExecuteNonQuery();
//            Console.WriteLine(rows5 + " row(s) updated in Courses");

//            con.Close();
//        }

//        // Task 10: Record payment for Jane Johnson
//        public static void RecordJanePayment()
//        {
//            SqlConnection con = db.GetConnection();
//            con.Open();

//            string enableIdentityInsert = "SET IDENTITY_INSERT Payments ON;";
            
//            SqlCommand enableCmd = new SqlCommand(enableIdentityInsert, con);
            

//            string insPayment = "INSERT INTO Payments (payment_id, student_id, amount, payment_date) " +
//                                 "VALUES (401, 101, 500.00, '2023-04-10')";
//            SqlCommand cmd6 = new SqlCommand(insPayment, con);

//            string disableIdentityInsert = "SET IDENTITY_INSERT Payments OFF;";
//            SqlCommand disableCmd = new SqlCommand(disableIdentityInsert, con);

//            enableCmd.ExecuteNonQuery();
//            cmd6.ExecuteNonQuery();
//            disableCmd.ExecuteNonQuery();

//            Console.WriteLine("1 row(s) inserted into Payments");

//            //According to pdf balance column does'nt exit so we cannot move further

//            con.Close();
//        }

//        // Task 11: Enrollment Report for Computer Science 4 (101 does not exists in my database so I put 4)
//        public static void GenerateEnrollmentReport()
//        {
//            SqlConnection con = db.GetConnection();
//            con.Open();

//            string query = "SELECT s.first_name, s.last_name, c.course_name " +
//                           "FROM Students s " +
//                           "JOIN Enrollments e ON s.student_id = e.student_id " +
//                           "JOIN Courses c ON e.course_id = c.course_id " +
//                           "WHERE c.course_name = 'Computer Science 4'";

//            SqlCommand cmd = new SqlCommand(query, con);
//            SqlDataReader reader = cmd.ExecuteReader();

//            Console.WriteLine("\nEnrollment Report for Computer Science 4:");
//            while (reader.Read())
//            {
//                Console.WriteLine("Student: " + reader["first_name"] + " " + reader["last_name"]);
//            }

//            con.Close();
//        }
//    }
//}
