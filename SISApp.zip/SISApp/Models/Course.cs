﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SISApp
{
    public class Course
    {
        //Task 1
        public int CourseId { get; set; }
        public string CourseName { get; set; }
        public string CourseCode { get; set; }
        public string InstructorName { get; set; }
        public Teacher AssignedTeacher { get; set; }

        //Task 5
        public List<Enrollment> Enrollments { get; set; } = new List<Enrollment>();

        //Task 2
        public Course(int courseId, string courseName, string courseCode, string instructorName)
        {
            CourseId = courseId;
            CourseName = courseName;
            CourseCode = courseCode;
            InstructorName = instructorName;
        }

        //Task 3
        public void AssignTeacher(Teacher teacher)
        {
            AssignedTeacher = teacher;
        }

        //Task 3
        public void UpdateCourseInfo(string code, string name, string instructor)
        {
            CourseCode = code;
            CourseName = name;
            InstructorName = instructor;
        }

        //Task 3
        public void DisplayCourseInfo()
        {
            Console.WriteLine($"Course: {CourseName} ({CourseCode}), Instructor: {InstructorName}");
        }

        //Task 3
        public List<Enrollment> GetEnrollments()
        {
            return Enrollments;
        }

        //Task 3
        public Teacher GetTeacher()
        {
            return AssignedTeacher;
        }
    }
}
