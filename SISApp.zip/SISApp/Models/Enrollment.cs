﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SISApp
{
    public class Enrollment
    {
        //Task 1
        public int EnrollmentId { get; set; }
        public int StudentId { get; set; }
        public int CourseId { get; set; }
        public string EnrollmentDate { get; set; }

        //Task 5
        public Student Student { get; set; }
        public Course Course { get; set; }

        //Task 2
        public Enrollment(int id, int studentId, int courseId, string date)
        {
            EnrollmentId = id;
            StudentId = studentId;
            CourseId = courseId;
            EnrollmentDate = date;
        }

        //Task 3
        public Student GetStudent()
        {
            return Student;
        }

        //Task 3
        public Course GetCourse()
        {
            return Course;
        }
    }
}
