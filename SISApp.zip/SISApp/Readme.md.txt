Folder Structure:-

SISApp
├── Database
│   └── DBHandler.cs         // Task 7 DB connection
├── exceptions
│   └── exception.cs         // Task 4 custom exceptions
├── Models                   // Task 1–3 class models
│   ├── Course.cs
│   ├── Enrollment.cs
│   ├── Payment.cs
│   ├── Student.cs
│   └── Teacher.cs
├── System_Logic
│   └── SIS.cs               // Task 3, 6 logic functions
├── Tasks                    // Task 7–11 operations
│   ├── Retrieval.cs
│   ├── StudentData.cs
│   └── Task_8_9_10_11.cs
├── App.config                    
└── Program.cs               // Main execution file


Note:- In the Database folder you will find DBHandler.cs where you can change server name from there.