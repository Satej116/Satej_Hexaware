﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SISApp
{
    class Program
    {
        static void Main(string[] args)
        {
            SIS system = new SIS();

            // (Task 2)
            Student student1 = new Student(1, "Amit", "Sharma", "2000-01-10", "amit@example.com", 9876543210);
            system.Students.Add(student1);

            // (Task 2)
            Course course1 = new Course(1, "Data Structures", "CS101", "Dr. Mehta");
            system.Courses.Add(course1);

            // (Task 2) 
            Teacher teacher1 = new Teacher(1, "Meena", "Kumari", "meena@college.edu");
            system.Teachers.Add(teacher1);

            // (Task 3)
            Console.WriteLine("\n Task 3: Student Info ");
            student1.DisplayStudentInfo();
            student1.UpdateStudentInfo("Amit", "Sharma", "2000-01-10", "amit.new@example.com", 9876543210);
            student1.MakePayment(5000, "2025-06-26");

            // (Task 6)
            system.AssignTeacherToCourse(course1, teacher1);

            // (Task 3)
            Console.WriteLine("\nEnrolled Courses:");
            foreach (var c in student1.GetEnrolledCourses())
            {
                Console.WriteLine(c.CourseName);
            }

            Console.WriteLine("\nPayment History:");
            foreach (var p in student1.GetPaymentHistory())
            {
                Console.WriteLine(p.Amount + " paid on " + p.PaymentDate);
            }

            // (Task 3)
            Console.WriteLine("\n Task 3: Course Info ");
            course1.DisplayCourseInfo();
            course1.UpdateCourseInfo("CS101", "Advanced DS", "Dr. Gupta");
            Console.WriteLine("Teacher: " + course1.GetTeacher().FirstName);

            Console.WriteLine("Enrollments in Course:");
            foreach (var e in course1.GetEnrollments())
            {
                Console.WriteLine("Student ID: " + e.StudentId);
            }

            // (Task 3)
            Console.WriteLine("\n Task 3: Teacher Info ");
            teacher1.DisplayTeacherInfo();
            teacher1.UpdateTeacherInfo("Meena Kumari", "meena.k@college.edu", "Data Structures");
            Console.WriteLine("Assigned Courses:");
            foreach (var c in teacher1.GetAssignedCourses())
            {
                Console.WriteLine(c.CourseName);
            }

            // (Task 3 and 6)
            system.AddEnrollment(student1, course1, "2025-06-25");

            // (Task 3)
            Console.WriteLine("\n Task 3: Enrollment ");
            var enrollment = system.GetEnrollmentsForStudent(student1)[0];
            Console.WriteLine("Enrolled Student: " + enrollment.GetStudent().FirstName);
            Console.WriteLine("Course: " + enrollment.GetCourse().CourseName);

            // (Task 3)
            Console.WriteLine("\n Task 3: Payment ");
            var payment = student1.Payments[0];
            Console.WriteLine("Paid by: " + payment.GetStudent().FirstName);
            Console.WriteLine("Amount: Rs. " + payment.GetPaymentAmount());
            Console.WriteLine("Date: " + payment.GetPaymentDate());

            Console.WriteLine("\n--------------Database Part-------------");

            // (Task 7) DB Connection
            Console.WriteLine("\n Task 7: DB Connection ");
            DBHandler db = new DBHandler();
            db.ConnectToDatabase();

            // (Task 7)
            Console.WriteLine("\n1. All Students:");
            Retrieval.GetAllStudents();

            // (Task 7)
            Console.WriteLine("\n2. All Courses:");
            Retrieval.GetAllCourses();

            // (Task 7)
            Console.WriteLine("\n3. All Teachers:");
            Retrieval.GetAllTeachers();

            // (Task 7)
            Console.WriteLine("\n4. All Enrollments:");
            Retrieval.GetAllEnrollments();

            // (Task 7)
            Console.WriteLine("\n5. All Payments:");
            Retrieval.GetAllPayments();

            //(Task 7)
            //StudentData.AddStudent("Sanika", "Patil", "2002-03-21", "sanika@example.com", "7894561224");

            //StudentData.UpdateStudentEmail(1, "newamit@example.com");

            //StudentData.EnrollStudentWithPayment(1, 2, "2025-06-28", 1500, "2025-06-29");

            ////(Task 8) Enroll John Doe in 2 courses
            //Console.WriteLine("\n Task 8: Enroll John Doe ");
            //Task_8_9_10_11.EnrollJohnDoe();

            //// (Task 9) Assign Sarah Smith to CS302
            //Console.WriteLine("\n Task 9: Assign Teacher ");
            //Task_8_9_10_11.AssignTeacherToCourse();

            //// (Task 10) Record Jane's payment
            //Console.WriteLine("\n Task 10: Payment for Jane ");
            //Task_8_9_10_11.RecordJanePayment();

            //// (Task 11) Generate Enrollment Report
            //Console.WriteLine("\n Task 11: Enrollment Report ");
            //Task_8_9_10_11.GenerateEnrollmentReport();

            Console.ReadLine();
        }
    }
}
